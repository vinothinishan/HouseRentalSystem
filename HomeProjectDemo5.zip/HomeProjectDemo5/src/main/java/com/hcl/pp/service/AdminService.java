package com.hcl.pp.service;

import java.util.List;

import com.hcl.pp.model.Admin;
import com.hcl.pp.model.User;

import jakarta.validation.Valid;

public interface AdminService {
	public User addUser(User user) ;

	public User updateUser(User user) ;
		
	public boolean removeUser(User user) ;

	public List<User> listUsers() ;
	
	public List<Admin> listAdmins() ;

	public Admin addAdmin(Admin admin);

}
