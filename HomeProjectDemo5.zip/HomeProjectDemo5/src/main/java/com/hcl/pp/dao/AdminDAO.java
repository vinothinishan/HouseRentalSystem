package com.hcl.pp.dao;

import java.util.List;
import java.util.Set;

import com.hcl.pp.model.Admin;
import com.hcl.pp.model.House;
import com.hcl.pp.model.User;

public interface AdminDAO {
	
	public User addUser(User user);
	
	public Admin addAdmin(Admin admin);

	public User updateUser(User user);
	
	public boolean removeUser(User user);

	public List<User> listUsers();
	
	public List<Admin> listAdmins();

}