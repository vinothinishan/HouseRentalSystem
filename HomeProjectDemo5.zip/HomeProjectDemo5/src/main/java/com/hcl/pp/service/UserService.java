package com.hcl.pp.service;

import java.util.List;
import java.util.Set;

import com.hcl.pp.model.Admin;
import com.hcl.pp.model.House;
import com.hcl.pp.model.User;

import jakarta.validation.Valid;

public interface UserService {
	public User addUser(User user) ;

	public User updateUser(User user) ;

	public List<User> listUsers() ;

	public User getUserById(long l) ;

	public boolean removeUser(User user) ;

	public User findByUserName(String username) ;

	public boolean buyHouse(House house, User user);

	public Set<House> getMyHouses(User user) ;

}
