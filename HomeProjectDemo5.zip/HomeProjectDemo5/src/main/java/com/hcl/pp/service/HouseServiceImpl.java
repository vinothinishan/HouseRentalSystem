package com.hcl.pp.service;

import java.util.List;
import java.util.Set;

import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.hcl.pp.actions.HousesAppController;
import com.hcl.pp.dao.HouseDAO;
import com.hcl.pp.dao.UserDAO;
import com.hcl.pp.model.House;
import com.hcl.pp.model.User;

@Service("houseService")
public class HouseServiceImpl implements HouseService {

	@Autowired
	private HouseDAO houseDAO;
	private static Logger logger = (Logger) LogManager.getLogger(HouseServiceImpl.class);

	@Override
	public boolean saveHouse(House house) {
		logger.info("Saving house");
		return houseDAO.saveHouse(house);
	}

	@Override
	public List<House> getAllHouses() {
		logger.info("Fetching House");
		return houseDAO.fetchAll();
	}

	@Override
	public House getHouseById(long HOUSE_ID) {
		logger.debug("Fetching house house by ID");
		return houseDAO.getHouseById(HOUSE_ID);
	}

	@Override
	public void deleteHouse(long HOUSE_ID) {
		houseDAO.deleteHouse(HOUSE_ID);
		
	}

	@Override
	public House updateHouse(House house) {
		return houseDAO.updateHouse(house);
	}

}
