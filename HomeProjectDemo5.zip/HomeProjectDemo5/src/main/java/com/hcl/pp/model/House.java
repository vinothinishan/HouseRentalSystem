package com.hcl.pp.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@NamedQueries({ @NamedQuery(name = "fetchAll", query = "from House"),
		@NamedQuery(name = "getHouseById", query = "from House house where house.Id= :id") })

@Component("house")
@Entity
@Table(name = "houses")
public class House implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HOUSE_ID")
	private long Id;
	@NotEmpty(message = "Enter House Owner Name")
	@Column(name = "HOUSEOWNER_NAME")
	private String name;
	@Column(name = "MOBILE_NUMBER")
	@Size(min = 10, max = 10, message = "Min length:10 , Max length:10")
	private long mobilenumber;
	@Column(name = "GENDER")
	@NotEmpty(message = "Enter Gender")
	private String gender;
	@Column(name = "EMAIL_ID")
	@NotEmpty(message = "Enter Email ID")
	@Pattern(regexp="^([a-zA-Z0-9\\-\\.\\_]+)'+'(\\@)([a-zA-Z0-9\\-\\.]+)'+'(\\.)([a-zA-Z]{2,4})$")
	private String email;
	@Column(name = "NO_OF_ROOMS")
	@NotEmpty(message = "Enter Number of rooms")
	private int noofrooms;
	@Column(name = "HOUSE_ADDRESS")
	@NotEmpty(message = "Enter Address")
	private String address;
	@Column(name = "CITY")
	@NotEmpty(message = "Enter City")
	private String city;
	@Column(name = "PINCODE")
	@NotEmpty(message = "Enter Pincode")
	@Size(min = 6, max = 6, message = "Min length:6 , Max length:6")
	private long pincode;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_ID")
	private User user;

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(long mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	

	public int getNoofrooms() {
		return noofrooms;
	}

	public void setNoofrooms(int noofrooms) {
		this.noofrooms = noofrooms;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	

}
