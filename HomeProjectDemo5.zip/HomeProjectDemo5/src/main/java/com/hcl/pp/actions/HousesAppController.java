package com.hcl.pp.actions;

import java.util.NoSuchElementException;
import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.persistence.Transient;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.pp.model.Admin;
import com.hcl.pp.model.House;
import com.hcl.pp.model.User;
import com.hcl.pp.service.AdminService;
import com.hcl.pp.service.HouseService;
import com.hcl.pp.service.SecurityService;
import com.hcl.pp.service.UserService;

import jakarta.validation.Valid;

@Controller
@SessionAttributes("sessionuser")
public class HousesAppController {
	@Autowired
	private UserService userService;
	@Autowired
	private AdminService adminService;
	@Autowired
	private HouseService houseService;
	@Autowired
	private SecurityService securityService;
	private static Logger logger = (Logger) LogManager.getLogger(HousesAppController.class);
	
	@RequestMapping(value = "/")
	public ModelAndView listEmployee(ModelAndView model) throws IOException {
		model.addObject("user", new User());
		model.setViewName("menu");
		return model;
	}
	@RequestMapping(value = "/user")
	public String welcome(Model model) {
		logger.info("Opened login page");
		model.addAttribute("user", new User());
		return "login";
	}
	
	@RequestMapping(value = "/user/add")
	public ModelAndView addUser(@Valid @ModelAttribute("user") User user, BindingResult bindingResult) {
		ModelAndView modelAndView = null;
		logger.info(user.getUserPassword() + " " + user.getConfirmPassword());
		if (bindingResult.getErrorCount() == 0 && user.getUserPassword().equals(user.getConfirmPassword())) {
			userService.addUser(user);
			modelAndView = new ModelAndView("registered");
		} else {
			logger.error(user.getUsername() + " " + user.getUserPassword() + " " + user.getConfirmPassword());
			modelAndView = new ModelAndView("userregn");
			modelAndView.addObject("nomatch", "Password and confirm password should be equal");
		}
		return modelAndView;
	}
 

	@RequestMapping(value = "/user/new")
	public String newUser(@ModelAttribute("user") User user) {
		logger.info("New User Entry");
		return "userregn";
	}

	@RequestMapping(value = "/user/logout")
	public String logout(@ModelAttribute("sessionuser") User user) {
		logger.info(user.getUsername() + " logged out");
		return "login";
	}

	@RequestMapping(value = "/houses/myHouses")
	public String myHouses(@ModelAttribute("sessionuser") User user, Model model) {
		Set<House> houses = userService.getMyHouses(user);
		model.addAttribute("houses", houses);
		logger.info("my houses info");
		return "my_houses";
	}

	@RequestMapping(value = "/houses/houseDetail")  
	public String submitForm( @Valid @ModelAttribute("house") House house, BindingResult br)  
    {  
        if(br.hasErrors())  
        {  
        	houseService.saveHouse(house);
    		logger.debug(house.getName() + " adding houses");
    		return "house_home";
        }  
        else  
        {  
        return "house_form";  
        }  
    }  
	
	@RequestMapping(value = "/houses/addHouse")
	public String addHouse(@ModelAttribute("house") House house) {
		houseService.saveHouse(house);
		logger.debug(house.getName() + " added");
		return "house_home";
	}
	
	@RequestMapping(value = "/user/authenticate")
	public ModelAndView authenticateUser(@ModelAttribute("user") User user, Model model) {
		ModelAndView modelAndView = null;
		try {
			User sessionuser = securityService.authenticateUser(user);
			modelAndView = new ModelAndView("house_home");
			model.addAttribute("sessionuser", sessionuser);
		} catch (NoSuchElementException exception) {
			modelAndView = new ModelAndView("userregn");
			modelAndView.addObject("nouser", "No such user, Please register");
			logger.warn(user.getUsername() + " " + user.getUserPassword()
					+ " not in the database, redirecting to user registration page");
		}
		return modelAndView;
	};
	@RequestMapping(value = "house/deleteHouse", method = RequestMethod.GET)
	public ModelAndView deleteHouse(HttpServletRequest request) {
		int houseId = Integer.parseInt(request.getParameter("HOUSE_ID"));
		houseService.deleteHouse(houseId);
		return new ModelAndView("redirect:/house_home");
	}

	@RequestMapping(value = "houses/editHouse", method = RequestMethod.GET)
	public ModelAndView editHouse(HttpServletRequest request) {
		int houseId = Integer.parseInt(request.getParameter("HOUSE_ID"));
		House house = houseService.getHouseById(houseId);
		ModelAndView model = new ModelAndView("house_form");
		model.addObject("house", house);

		return model;
	}

	@RequestMapping(value = "/houses/buyHouse", method = RequestMethod.GET)
	public String buyHouse(@ModelAttribute("sessionuser") User user, @RequestParam long houseId) {
		House house = houseService.getHouseById(houseId);
		userService.buyHouse(house, user);
		logger.debug(house.getName() + " bought by" + user.getUsername());
		return "house_home";
	}

	@RequestMapping(value = "/user/registered")
	public String registered(@ModelAttribute("user") User user) {
		logger.info(user.getUsername() + " registered");
		return "registered";
	}

	@RequestMapping(value = "/houses")
	public String houseHome(Model model) {
		List<House> houses = houseService.getAllHouses();
		model.addAttribute("houses", houses);
		logger.info("directing to house home page");
		return "house_home";
	}
	@RequestMapping(value = "/admin")
	public String Adminwelcome(Model model) {
		logger.info("Opened adminlogin page");
		model.addAttribute("admin", new Admin());
		return "admin";
	}

	@RequestMapping(value = "/admin/authenticate")
	public ModelAndView authenticateAdmin(@ModelAttribute("admin") Admin admin, Model model) {
		ModelAndView modelAndView = null;
		try {
			Admin sessionuser = securityService.authenticateAdmin(admin);
			modelAndView = new ModelAndView("house_home");
			model.addAttribute("sessionuser", sessionuser);
		} catch (NoSuchElementException exception) {
			modelAndView = new ModelAndView("adminregn");
			modelAndView.addObject("nouser", "No such admin user, Please register");
			logger.warn(admin.getUsername() + " " + admin.getUserPassword()
					+ " not in the database, redirecting to admin registration page");
		}
		return modelAndView;
	}
	@RequestMapping(value = "/admin/addadmin")
	public ModelAndView addAdmin(@Valid @ModelAttribute("admin") Admin admin, BindingResult bindingResult) {
		ModelAndView modelAndView = null;
		logger.info(admin.getUserPassword() + " " + admin.getConfirmPassword());
		if (bindingResult.getErrorCount() == 0 && admin.getUserPassword().equals(admin.getConfirmPassword())) {
			adminService.addAdmin(admin);
			modelAndView = new ModelAndView("adminregistered");
		} else {
			logger.error(admin.getUsername() + " " + admin.getUserPassword() + " " + admin.getConfirmPassword());
			modelAndView = new ModelAndView("adminregn");
			modelAndView.addObject("nomatch", "Password and confirm password should be equal");
		}
		return modelAndView;
	}
	@RequestMapping(value = "/admin/new")
	public String newUser(@ModelAttribute("admin") Admin admin) {
		logger.info("New Admin Entry");
		return "adminregn";
	}
	@RequestMapping(value = "/admin/registered")
	public String registered(@ModelAttribute("admin") Admin admin) {
		logger.info(admin.getUsername() + " registered");
		return "adminregistered";
	}


}
